import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { Product } from 'src/app/productos/Product';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss']
})
export class ProductComponent implements OnInit {
  @Input() product: Product;
  @Output() selected = new EventEmitter();
  @Output() selected2 =  new EventEmitter();
  @Output() erase = new EventEmitter();
  erasingSubscription = new Subscription();
  numberChecked: number;
  flag: boolean;

  constructor() { }

  ngOnInit(): void {
    this.numberChecked = 0;
  }

  select(){
    this.numberChecked++;
    //console.log(((this.numberChecked/2)).toFixed(0));
    this.selected.emit((this.numberChecked / 2).toFixed(0));
  }

  selectedBox(){ // manda el id si esta seleccionado
    if(!this.flag){
      this.selected2.emit(this.product.uid);
    }
  }

  erasePls(){
    this.erase.emit(this.product.uid);
  }
}
