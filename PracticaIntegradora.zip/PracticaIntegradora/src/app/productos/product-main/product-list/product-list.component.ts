import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ProductsService } from '../../products.service';
import { Product } from '../../Product';
import { Router } from '@angular/router';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.scss']
})
export class ProductListComponent implements OnInit {

  search: '';
  productos: Product[];
  FilteredProd: Product[];
  uids: number[];
  flag: boolean;
  //uidToErase: number;
  url: string;
  checkedBoxes: number;
  tempArr: Product[];

  prodMon: Product[];

  constructor(private productService: ProductsService, router: Router) {
    this.productos = this.productService.getProducts();
    this.FilteredProd = this.productos.slice();
    this.uids = [];
    this.url = router.url;
    this.prodMon = this.productService.getMonProd();
  }

  ngOnInit(): void {
    if(this.url === '/product') {
      this.flag = false;
    } else {
      this.flag = true;
    }
  }

  searching() {
    this.FilteredProd = this.productos.filter(p => p.nombre.toUpperCase().includes(this.search.toUpperCase())
    || p.descripcion.toUpperCase().includes(this.search.toUpperCase()));
  }

  selectedProd(num){
    this.checkedBoxes = num;
  }

  selectedBox(uid){

    if(!(this.uids.includes(uid))){
      this.uids.push(uid);
    }
    
    console.log("uids, lista ", this.uids);
  }

  erase(uid){
    if(this.url === '/product'){
      for(let i = 0; i < this.productos.length; i++) {
        if(this.productos[i].uid === uid) {
          this.productos.splice(i, i + 1);
        }
      }
    }
    //this.productService.erasePls(uid);
    console.log("productos_lista: ",this.productos);
  }

  addToMon(){
    this.productService.addProductsMonitoreado(this.uids);
    console.log("prodMonlISTA:",this.prodMon);
    //console.log("product service: ", this.productService.getMonProd());
  }
}
