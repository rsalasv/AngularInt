import { Injectable } from '@angular/core';
import { Product, Especificacion } from './Product';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {
  productos: Product[];
  idMon: Product[];
  esp: Especificacion[];

  productSubject = new Subject<Product[]>();

  constructor() {
    this.esp = [new Especificacion('papa', 13, 'kg')];
    this.productos = [new Product(0, 'papa', 'granel', 'papa grande', 13, 700, this.esp, "https://q.miximages.com/10000/Crops/main-qimg-6e7bd0e97c1681eb5eb19cdafbd7d40a-c.jpg"),
                      new Product(1, 'pitayas', 'cerro grande', 'pitaya bby', 30, 109, this.esp, "https://vallartatribune.com/wp-content/cache/thumbnails/2016/06/pitaya-4-820x410-c.jpg")];
    this.idMon = [];
  }

  getProducts(): Product[] {
    return this.productos;
  }

  erasePls(uid) {
    for(let i = 0; i < this.productos.length; i++) {
      if(this.productos[i].uid === uid) {
        this.productos.splice(i, i + 1);
      }
    }
  }

  addProductsMonitoreado(uids:number[]){ // añade productos a monitoreado
    
    let temporal: Product[];
    // tslint:disable-next-line: prefer-for-of
    console.log("uids: ", uids);
    for(let i = 0; i < uids.length; i++){
      temporal = this.productos.filter(p => p.uid == uids[i]);
      console.log(temporal);
      //si no esta el uid en monitoreados, y temporal es menor o igual a 1, se añade el temporal
      if(!(this.idMon.some(p => p.uid == uids[i])) && (temporal.length <= 1)){ 
        this.idMon.push(temporal[0]);
      }
    }
    console.log("idMon: ", this.idMon);
  }

  getMonProd(){
    return this.idMon.slice();
  }
}
